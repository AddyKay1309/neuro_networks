import * as THREE from "three";

import { scene } from "./globe.js";

import {

    GLOBE_RADIUS,

    PARTICLE_COUNT,

    GLOBE_COLOR,

    GLOBE_POSITION

} from "./constants.js";
// ==========================================================
// FIBONACCI PARTICLES
// ==========================================================

const positions = [];

const goldenAngle = Math.PI * (3 - Math.sqrt(5));

for (let i = 0; i < PARTICLE_COUNT; i++) {

    const y = 1 - (i / (PARTICLE_COUNT - 1)) * 2;

    const r = Math.sqrt(1 - y * y);

    const theta = goldenAngle * i;

    const x = Math.cos(theta) * r;

    const z = Math.sin(theta) * r;

    positions.push(

        x * GLOBE_RADIUS,

        y * GLOBE_RADIUS,

        z * GLOBE_RADIUS

    );

}
// ==========================================================
// GEOMETRY
// ==========================================================

export const particleGeometry = new THREE.BufferGeometry();

particleGeometry.setAttribute(

    "position",

    new THREE.Float32BufferAttribute(

        positions,

        3

    )

);
// ==========================================================
// MATERIAL
// ==========================================================

const particleMaterial = new THREE.PointsMaterial({

    color: GLOBE_COLOR,

    size: 0.017,

    transparent: true,

    opacity: 0.95,

    depthWrite: false,

    blending: THREE.AdditiveBlending

});
// ==========================================================
// GLOBE
// ==========================================================

export const globe = new THREE.Points(

    particleGeometry,

    particleMaterial

);

globe.position.set(

    GLOBE_POSITION.x,

    GLOBE_POSITION.y,

    GLOBE_POSITION.z

);

scene.add(globe);
// ==========================================================
// ATMOSPHERE
// ==========================================================

export const atmosphere = new THREE.Mesh(

    new THREE.SphereGeometry(

        GLOBE_RADIUS + 0.08,

        64,

        64

    ),

    new THREE.MeshBasicMaterial({

        color: GLOBE_COLOR,

        transparent: true,

        opacity: 0.08,

        side: THREE.BackSide

    })

);

atmosphere.position.copy(

    globe.position

);

scene.add(

    atmosphere

);
